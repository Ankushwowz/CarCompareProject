
<section id="portfolio" class="">
   <div class="page-heading-two">
      <div class="container">
	  
         <div class="col-md-7">
            <h5>Home <span>Contact</span></h5>
         </div>	
        
         <div class="clearfix"></div>
      </div>
   </div>
   <div class="container div_center">
      <div class="col-md-8 col-sm-12 col-xs-12">
         <form action="" method="post" role="form" novalidate="" class="form-horizontal"  id="contact-form">
            <div class="row">
			<h4>Contact Form</h4>
			<hr/>
			<div class="alert alert-success alert-dismissible" id="msg-contact-form" style="display:none;">
							<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							Your information has been sent successfully.we will be contact shortly
							</div>
               <div class="col-md-6">
                  <label class="control-label">First Name</label>                                
                  <input id="fname" type="text" name="fname" placeholder="First Name" value="" class="form-control " required='true'>
                  
               </div>
			    <div class="col-md-6">
                  <label class="control-label">Last Name</label>                                
                  <input id="lname" type="text" name="lname" placeholder="Last Name" value="" class="form-control " required='true'>
                  
               </div>
               <div class="col-md-12">
                  <label class="control-label">Email</label>
                  <input id="email" type="email" name="email" placeholder="Email" value="" class="form-control"  required='true'>
                 
               </div>
               <div class="col-md-12">
                           <label class="control-label">Message</label> <textarea rows="5" name="message" class="form-control" ></textarea>
               </div>
              
              <div class="col-md-6">
                  <label class="control-label">Vehicle Make</label>                                
                  <input id="vehicleMake" type="text" name="vehicleMake" placeholder="Vehicle Make" value="" class="form-control " required='true'>
                </div>
           <div class="col-md-6">
                  <label class="control-label">Vehicle Model</label>                                
                  <input id="vehicleModel" type="text" name="vehicleModel" placeholder="Vehicle Model" value="" class="form-control " required='true'>
            </div>
			<div class="col-md-6">
                  <label class="control-label">Vehicle Reg No</label>                                
                  <input id="vehicleRegNo" type="text" name="vehicleRegNo" placeholder="Vehicle Reg No" value="" class="form-control " required='true'>
              </div>
			  <div class="col-md-6">
                  <label class="control-label">Year of Manufacture</label>                                
                  <input id="yearofManufacture" type="text" name="yearofManufacture" placeholder="Year of Manufacture" value="" class="form-control numbervalidation" required='true'>
              </div>
			  <div class="col-md-6">
                  <label class="control-label">Value of Vehicle</label>                                
                  <input id="valueofVehicle" type="text" name="valueofVehicle" placeholder="Value of Vehicle" value="" class="form-control numbervalidation" required='true'>
              </div>
            <div class="row">
               <div class="col-md-12 pt_40">
                  <div class="form-group" style="text-align:center">
					
					<input type="submit" class="btn btn-success" value="Submit" >
                  </div>
               </div>
            </div>
        </form>
     
	 </div>
   </div>
   
	

</section>