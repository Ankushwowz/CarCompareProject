<style>
    .success_message {min-height: calc(100vh - 607px);align-items: center;}
    .success_message .alert {padding: 8px 55px;}
</style>
<div class="container div_center success_message">
<div class="row">
<div class="col-md-12">
<div class="alert alert-success">
  <p>Payment made to PesaPal was <strong><?= strtoupper($response); ?></strong></p>
</div>

</div>
</div>
</div>
     
