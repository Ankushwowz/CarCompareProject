<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="edit-profile-header">
        <h1>Edit Profile</h1>
    </section>
    <section class="edit-profile-content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box admin-box">
                   <!-- /.box-header -->
                   <div class="box-body">
    				<?php 
    				$success = $this->session->flashdata('success');
    				if($success){?>
    					<div class="alert alert-success alert-dismissable">
    						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    						<?php echo $success; ?>                    
    					</div><?php 
    				} ?>
    				
                        <form action="<?php echo base_url()?>administrator/editprofile" method="post" role="form" novalidate=""  id="editprofile" enctype="multipart/form-data">
    					    <div class="row">
                                <div class="col-sm-12 form-group">
                                    <label for="name" class="col-sm-3 control-label">First Name <span class="text-danger"></span></label>
                                    <div class="col-sm-6">
                                        <input type="text" name="first_name" value="<?php if(!empty($profile['first_name'])) { echo $profile['first_name']; } ?>" placeholder="First Name" class="form-control" required="true">
                                    </div>
                                </div>
            
                                <div class="col-sm-12 form-group">
                                    <label for="name" class="col-sm-3 control-label">Last Name <span class="text-danger"></span></label>
                                    <div class="col-sm-6">
                                        <input type="text" name="last_name" value="<?php if(!empty($profile['last_name'])) { echo $profile['last_name']; } ?>" placeholder="Last Name" class="form-control" required="true">
                                    </div>
                                </div>
                                <div class="col-sm-12 form-group">
                                    <label for="email" class="col-sm-3 control-label">Phone</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="phone" value="<?php if(!empty($profile['user_phone'])) { echo $profile['user_phone']; } ?>" placeholder="Phone" class="form-control">
                                    </div>
                                </div>
                                <div class="col-sm-12 form-group">
                                    <label for="password" class="col-sm-3 control-label">Password <span class="text-danger"></span></label>
                                    <div class="col-sm-6">
                                        <input id="password" type="password" name="password" placeholder="Password" class="form-control" required="true">
                                    </div>
                                </div>
            					<div class="col-sm-12 form-group">
                                    <label for="password" class="col-sm-3 control-label">Profile Image <span class="text-danger"></span></label>
                                    <div class="col-sm-6">
                                        <input  type="file" name="userfile"  class="form-control" required="true">
            							<input  type="hidden" name="olduserfile"  class="form-control"  value="<?php if(!empty($profile['profile_image'])) { echo $profile['profile_image']; } ?>">
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <p class="ad-heading">Agency Details</p>
                                </div>
                                <div class="col-sm-12 form-group">
                                    <label for="email" class="col-sm-3 control-label">Company Name</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="company_name" value="<?php if(!empty($profile['user_company'])) { echo $profile['user_company']; } ?>" placeholder="Company Name" class="form-control">
                                    </div>
                                </div>
                                <div class="col-sm-12 form-group">
                                    <label for="email" class="col-sm-3 control-label">Website</label>
                                    <div class="col-sm-6">
                                        <input type="text" name="website" value="<?php if(!empty($profile['user_website'])) { echo $profile['user_website']; } ?>" placeholder="Website" class="form-control">
                                    </div>
                                </div>
        						<div class="col-sm-12 form-group">
                                    <div class="col-sm-offset-3 col-sm-6">
                                        <input  name="submit-btn" type="submit" class="btn btn-success" value="Submit">&nbsp;
            						</div>
                                </div>
    					    </div>
    			        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>