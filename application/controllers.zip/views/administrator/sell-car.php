#popup .modal-dialog {position: absolute;top: 40%;left: 30%;}

<style>
td {border: 0 !important;}
table.dataTable thead th, table.dataTable thead td {border-bottom: 0 !important;}
</style>
<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>Your Listed Inventory </h1>
   </section>
   <section class="content">
      
      <div class="row">
         <div class="col-xs-12">
            <div class="box admin-box">
               <!-- /.box-header -->
               <div class="box-body table-responsive">
                  
                  <table id="example" class="display table table-hover table-downs" style="width:100%">
                     <thead>
                        <tr>
                           <th>Title</th>
                           <th>Advert Type</th>
                          
                           <th>Package</th>
                           <th>Action</th>
							
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                           if(!empty($Records)){
								foreach($Records as $record){ ?>
									<tr>
									   <td><?php echo $record->title; ?></td>
									   <td><?php echo ucfirst($record->advert_type); ?></td>
									   <td><?php echo ucfirst($record->package); ?></td>
									   <td> 
									        <a href="<?php echo base_url();?>edit-vehicle/<?php echo base64_encode($record->id);?>" class="btn btn-primary">Edit</a>
									        <a href="javascript:;" rel="<?php echo $record->id;?>" class="btn btn-danger delete-vehicle">Delete</a>
											<?php if($record->advert_type=='rent'){?>
									        <a href="#" class="btn btn-warning unavailable" data-toggle="modal" data-target="#popup" rel="<?php echo $record->id;?>" >Unavailable</a><?php } ?>
											<?php if($record->advert_type=='rent'){?>
											  <a href="javascript:;" rel="<?php echo $record->id;?>" class="btn btn-success available-vehicle">Available</a>
											<?php } ?>
									   </td>
									  
									 </tr><?php
								}
                           } ?>
                     </tbody>
                  </table>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
      </div>
   </section>
   
   
									<div id="popup" class="modal fade" role="dialog">
											<div class="modal-dialog">

											<!-- Modal content-->
											<div class="modal-content">
											<div class="modal-header" style="background-color: #3259ca;color: #fff;">
											<button type="button" class="close" data-dismiss="modal">&times;</button>
											<h4 class="modal-title">Unavailable</h4>
											</div>
											<div class="modal-body">
											<div  id="unavailable-success" style="display:none;" class="alert alert-success" >Your Information has been added successfully.</div>
											<div class="form-group">
											<label for="f-unavailable">Unavailable Date:</label>
											<input min="<?php echo date('Y-m-d');?>"  type="date" class="form-control" id="unavailable" value="<?php echo date('Y-m-d');?>">
											<input type="hidden" class="form-control" id="postid" value="" >
											
											</div>
											</div>
											<div class="modal-footer">
											<button type="button" class="btn btn-success" id="saveunavailable" >Save</button>
											<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
											</div>
											</div>

											</div>
											</div>
</div>

<!-- Modal -->
