<style>
.add-clss {float:right;}
td {border: 0 !important;}
table.dataTable thead th, table.dataTable thead td {border-bottom: 0 !important;}
</style>
<div class="content-wrapper">
   <!-- Content Header (Page header) -->
   <section class="content-header">
      <h1>
         <i class="fa fa-users"></i> Model  Management
         <small></small>
         <span style="float-right"><a href="<?php echo base_url();?>administrator/addmodel" class="add-clss btn btn-success">Add New Model</a></span>
      </h1>
   </section>
   <section class="content">
      
      <div class="row">
         <div class="col-xs-12">
            <div class="box admin-box">
               <!-- /.box-header -->
               <div class="box-body table-responsive">
                  <?php 
        $success = $this->session->flashdata('success');
        if($success)
        {
            ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $success; ?>                    
            </div>
        <?php } ?>
                  <table id="example" class="display table table-hover table-downs" style="width:100%">
                     <thead>
                        <tr>
                           <th>Brand Name</th>
                           <th>Body Type Name</th>
                           <th>Model Name</th>
                           <th>Action</th>
							
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                           if(!empty($Records)){
								foreach($Records as $record){ ?>
									<tr>
									   <td><?php echo $record->brandname; ?></td>
									   <td><?php echo $record->title; ?></td>
									   <td><?php echo $record->modelname; ?></td>
									 
									   <td><a href="<?php echo base_url();?>administrator/editmodel/<?php echo $record->id;?>"  class="btn btn-success ">Edit</a> <a href="javascript:;" rel="<?php echo $record->id;?>" class="btn btn-danger delete-brand">Delete</a> </td>
									  
									 </tr><?php
								}
                           } ?>
                     </tbody>
                  </table>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
      </div>
   </section>
</div>